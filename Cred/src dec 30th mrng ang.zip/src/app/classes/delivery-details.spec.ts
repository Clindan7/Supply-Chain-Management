import { DeliveryDetails } from './delivery-details';

describe('DeliveryDetails', () => {
  it('should create an instance', () => {
    expect(new DeliveryDetails()).toBeTruthy();
  });
});

