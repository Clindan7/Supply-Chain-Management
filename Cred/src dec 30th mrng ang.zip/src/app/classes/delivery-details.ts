import { UserDetails } from "./user-details";

export class DeliveryDetails {

    user=new UserDetails();
    userId:any;
    dPersonId:any;
    dPersonName:any;
    // location:any;
    mobile:any;
    route:any;
    
}
