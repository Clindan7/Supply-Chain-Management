import { UserDetails } from "./user-details";

export class SupplierDetails {
    user=new UserDetails();
    userId:any;
    supplierId:any;
    supplierName:any;
    location:any;
    mobile:any;
}
