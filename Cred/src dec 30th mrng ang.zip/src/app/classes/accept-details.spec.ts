import { AcceptDetails } from './accept-details';

describe('AcceptDetails', () => {
  it('should create an instance', () => {
    expect(new AcceptDetails()).toBeTruthy();
  });
});
