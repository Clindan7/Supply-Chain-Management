import { PostOrder } from './post-order';

describe('PostOrder', () => {
  it('should create an instance', () => {
    expect(new PostOrder()).toBeTruthy();
  });
});
