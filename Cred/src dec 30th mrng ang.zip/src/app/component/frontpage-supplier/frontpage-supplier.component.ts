import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-frontpage-supplier',
  templateUrl: './frontpage-supplier.component.html',
  styleUrls: ['./frontpage-supplier.component.css']
})
export class FrontpageSupplierComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
