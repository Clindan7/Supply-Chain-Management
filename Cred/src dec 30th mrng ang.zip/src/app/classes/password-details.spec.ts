import { PasswordDetails } from './password-details';

describe('PasswordDetails', () => {
  it('should create an instance', () => {
    expect(new PasswordDetails()).toBeTruthy();
  });
});
