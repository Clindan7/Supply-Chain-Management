export class UserDetails {
    userId:any;
    name:any;
    email:any;
    password:any;
    role:any;
}
