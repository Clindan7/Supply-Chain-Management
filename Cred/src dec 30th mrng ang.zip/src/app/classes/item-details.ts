export class ItemDetails {
    itemId:any;
    itemName:any;
    description:any;
    type:any;
    photos:any;
    quantity:any;
    supplier:any;
    address:any;
}
