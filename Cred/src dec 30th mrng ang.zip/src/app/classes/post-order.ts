

    import { AcceptDetails } from "./accept-details";


    
export class PostOrder {




    postOrderId:any;
    preOrderId:any;
    price:any;
    preorder=new AcceptDetails();
    dDate:any;
}


