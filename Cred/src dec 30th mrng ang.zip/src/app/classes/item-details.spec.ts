import { ItemDetails } from './item-details';

describe('ItemDetails', () => {
  it('should create an instance', () => {
    expect(new ItemDetails()).toBeTruthy();
  });
});
