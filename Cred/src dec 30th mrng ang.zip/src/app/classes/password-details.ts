export class PasswordDetails {
    oldpassword:any;
    newpassword:any;
    confirmpassword:any;
}
