package com.supplychain.supplychain.form;

public class EmailForm {
   
    
        private String to;
    
        public String getTo() {
            return to;
        }
    
        public void setTo(String to) {
            this.to = to;
        }
        
    }

