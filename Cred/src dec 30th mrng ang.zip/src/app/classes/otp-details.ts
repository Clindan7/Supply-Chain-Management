export class OtpDetails {

       
    id:any;
    otp:String|undefined;
    to:String|undefined;
}
