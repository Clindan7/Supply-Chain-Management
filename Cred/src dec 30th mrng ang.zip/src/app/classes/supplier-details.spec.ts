import { SupplierDetails } from './supplier-details';

describe('SupplierDetails', () => {
  it('should create an instance', () => {
    expect(new SupplierDetails()).toBeTruthy();
  });
});
