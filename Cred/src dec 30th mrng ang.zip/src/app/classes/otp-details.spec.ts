import { OtpDetails } from './otp-details';

describe('OtpDetails', () => {
  it('should create an instance', () => {
    expect(new OtpDetails()).toBeTruthy();
  });
});
